package atlantadragons.gatech.spacetrader;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.transition.Transition;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.arch.lifecycle.ViewModelProviders;
import android.widget.TextView;



public class TransitionActivity extends AppCompatActivity {

    private TransitionViewModel viewModel;
    private TextView welcomeTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState ) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.transitionactivity_configuration);
        welcomeTextView = findViewById(R.id.welcomeTextView);

        setTitle("Transition");
        viewModel = ViewModelProviders.of(this).get(TransitionViewModel.class);
        viewModel.setPlanets();
    }




}
