package atlantadragons.gatech.spacetrader;

import android.app.Application;
import android.arch.lifecycle.AndroidViewModel;
import android.support.annotation.NonNull;
import android.util.Log;

public class TransitionViewModel extends AndroidViewModel {

    public TransitionViewModel(@NonNull Application application) {
        super(application);
    }

    public void setPlanets() {
        Planet Adahn = new Planet("Adahn", 10, 10);
        System.out.println(Adahn.toString());
        Planet Brax = new Planet("Brax", 20, 20);
        System.out.println(Brax.toString());
        Planet Capelle = new Planet("Capelle", 30, 30);
        System.out.println(Capelle.toString());
        Planet Draylon = new Planet("Draylon", 40, 50);
        System.out.println(Draylon.toString());
        Planet Frolix = new Planet("Frolix", 60, 70);
        System.out.println(Frolix.toString());
        Planet Hades = new Planet("Hades", 100, 20);
        System.out.println(Hades.toString());
        Planet Korma = new Planet("Korma", 68, 15);
        System.out.println(Korma.toString());
        Planet Omega = new Planet("Omega", 44, 123);
        System.out.println(Omega.toString());
        Planet Utopia = new Planet("Utopia", 115, 60);
        System.out.println(Utopia.toString());
        Planet Zuul = new Planet("Zuul", 4, 85);
        System.out.println(Zuul.toString());

    }







}



