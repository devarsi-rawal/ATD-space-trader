package atlantadragons.gatech.spacetrader;

public enum GameMode {
    BEGINNER,
    EASY,
    MEDIUM,
    HARD,
    IMPOSSIBLE;
}
