package atlantadragons.gatech.spacetrader;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class Planet {

    private String name;
    private int xCoord;
    private int yCoord;
    private TechLevel techLevel;
    private Resources resource;

    public enum TechLevel {
        PRE_AGRICULTURAL("Pre-agricultural"),
        AGRICULTURAL("Agricultural"),
        MEDIEVAL("Medieval"),
        RENAISSANCE("Renaissance"),
        EARLY_INDUSTRIAL("Early-industrial"),
        INDUSTRIAL("Industrial"),
        POST_INDUSTRIAL("Post-industrial"),
        HI_TECH("Hi-tech");

        private static final List<TechLevel> VALUES = Arrays.asList(values());
        private static final int SIZE = VALUES.size();
        private static final Random RANDOM = new Random();

        public static TechLevel randomTechLevel()  {
            return VALUES.get(RANDOM.nextInt(SIZE));
        }
        private final String techLevel;
        TechLevel(String tech_level) { techLevel = tech_level; }
        public String getTechLeve() { return techLevel; }
        public String toString() { return techLevel; }
    }

    public enum Resources {
        NOSPECIALRESOURCES("No special resources"),
        MINERALRICH("Mineral rich"),
        MINERALPOOR("Mineral poor"),
        DESERT("Desert"),
        LOTSOFWATER("Lots of water"),
        RICHSOIL("Rich soil"),
        POORSOIL("Poor soil"),
        RICHFAUNA("Rich fauna"),
        LIFELESS("Lifeless"),
        WEIRDMUSHROOMS("Weird mushrooms"),
        LOTSOFHERBS("Lots of herbs"),
        ARTISTIC("Artistic"),
        WARLIKE("Warlike");

        private static final List<Resources> VALUES = Arrays.asList(values());
        private static final int SIZE = VALUES.size();
        private static final Random RANDOM = new Random();

        public static Resources randomResource()  {
            return VALUES.get(RANDOM.nextInt(SIZE));
        }
        private final String resource;
        Resources(String reSource) { resource = reSource; }
        public String getResource() { return resource; }
        public String toString() { return resource; }
    }


    public Planet(String name, int xCoord, int yCoord) {
        this.name = name;
        this.xCoord = xCoord;
        this.yCoord = yCoord;
        this.techLevel = TechLevel.randomTechLevel();
        this.resource = Resources.randomResource();
    }

    public String getName() { return name; }
    public int getxCoord() { return xCoord; }
    public int getyCoord() { return yCoord; }
    public TechLevel getTechLevel() { return techLevel; }
    public Resources getResouces() { return resource; }

    public void setName(String name) { this.name = name; }
    public void setxCoord(int x) { this.xCoord = x; }
    public void setyCoord(int y) { this.yCoord = y; }

    public String toString() {
        return String.format("Planet name: %s, X coord: %d, Y coord: %d, Tech Level: %s, Resource: %s", name, xCoord, yCoord, techLevel.toString(), resource.toString());
    }


}
